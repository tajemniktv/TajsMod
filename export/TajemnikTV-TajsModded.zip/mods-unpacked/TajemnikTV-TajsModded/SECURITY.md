# Security Policy

Please report security vulnerabilities privately via email to tajemniktv@outlook.com. Do not disclose publicly. Only the latest version of Taj's Mod is supported.
